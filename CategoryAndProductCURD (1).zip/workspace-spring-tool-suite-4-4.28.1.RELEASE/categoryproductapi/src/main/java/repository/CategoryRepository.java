package com.example.categoryproductapi.repository;

import com.example.categoryproductapi.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

// @Repository annotation is optional here since Spring Data JPA automatically considers interfaces extending JpaRepository as repositories
@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {

    // Custom query method to find a category by its name (Optional is used to avoid NullPointerException)
    Optional<Category> findByName(String name);

    // You can add other custom queries here if needed, for example:
    // List<Category> findByNameContaining(String keyword);  // To find categories by partial name match
}
