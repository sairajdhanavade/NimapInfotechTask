package com.example.categoryproductapi.repository;

import com.example.categoryproductapi.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

// @Repository annotation is optional here as well
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    // Custom query method to find products by category
    List<Product> findByCategoryId(Long categoryId);

    // Custom query method to find a product by its name
    Optional<Product> findByName(String name);

    // You can also define more custom queries here
    // List<Product> findByPriceGreaterThanEqual(Double price);  // To find products with a price greater than or equal to a certain amount
}
