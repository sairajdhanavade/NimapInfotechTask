package com.example.categoryproductapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoryproductapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CategoryproductapiApplication.class, args);
	}

}
