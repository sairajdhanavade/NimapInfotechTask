package com.example.categoryproductapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryproductapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
